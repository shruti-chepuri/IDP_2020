import numpy as np
import mpmath as mp
import matplotlib.pyplot as plt

def qfunc(x):
	return 0.5*mp.erfc(x/np.sqrt(2))

snrdb = np.linspace(0,14,15)
samples = int(10**6)
err = []
ber = []
noise_1 = np.random.normal(0,1,samples)
noise_2 = np.random.normal(0,1,samples)
for i in range(0,15):
	snr = 10**(0.1*snrdb[i])
	y1 = np.sqrt(2*snr) + noise_1      # when s0 is sent and variance of noice is unity
	y2 = noise_2                
	count = 0
	for j in range(0,len(y1)):
		if (y1[j]<y2[j]):
			count = count+1
	err.append(count/samples)
	ber.append(qfunc(np.sqrt(snr)))      #theoritically already proved 

plt.semilogy(snrdb,ber,label='theoritically')
plt.semilogy(snrdb,err,'o',label='simulation')
plt.xlabel('$\\left(\\frac{E_b}{N_0}\\right)$in db')
plt.ylabel('$P_e$')
plt.savefig('bfsk.eps')
plt.legend()
plt.grid()
plt.show()
