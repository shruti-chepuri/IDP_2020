import numpy as np
import mpmath as mp
import matplotlib.pyplot as plt


def qfunc(x):
	return 0.5*mp.erfc(x/np.sqrt(2))

snrdb = np.linspace(0,14,15)
samples = int(1e6)		
err = np.array([])
ber = np.array([])
noise1 = np.random.normal(0,1,samples)
noise2=np.random.normal(0,1,samples)

for i in range(0,15):
	snr = 10**(0.1*snrdb[i])
	y1 = np.sqrt(2*snr) + noise1
	y2 = noise2
	count = 0
	for j in range (0,len(y1)):
	    if ((y1[j]>y2[j]) and (y1[j]>-y2[j])):
	    	count = count + 1                
	err = np.append(err,(count/samples))
	ber= np.append(ber,(1-qfunc(np.sqrt(snr)))**2)
	
plt.semilogy(snrdb,ber,label='Theoritical')
#plt.semilogy(snrdb,err,'o',label='Simulation')
plt.xlabel('$\\left(\\frac{E_b}{N_0}\\right)$ in dB')
plt.ylabel('$P_e$')
plt.legend()
plt.savefig('qpsk.eps')
plt.show()
