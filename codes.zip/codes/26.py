from __future__ import division
import numpy as np
import mpmath as mp
import matplotlib.pyplot as plt


def qfunc(x):
	return 0.5*mp.erfc(x/np.sqrt(2))

snrlen = 10

snrdb = np.linspace(8,17,10)
samples = 10000
err = []
corr=[]
ber = []
err_given_snr=0
mean=0
var=1
noise1 = np.random.normal(mean,var**0.5,samples)
noise2=np.random.normal(mean,var**0.5,samples)
M=8
f1=np.tan(np.pi/M)
f2=1+(1/f1)**2
for i in range(0,snrlen):
		snr = 10**(0.1*snrdb[i])
		r_x = mp.sqrt(2*snr) + noise1
		r_y = noise2
		err_given_snr=0
		for j in range (0,len(r_x)):
		    if ((f1*r_x[j]>r_y[j]) and (f1*r_x[j]>-r_y[j])):
		    	err_given_snr=err_given_snr+1               
		corr.append(err_given_snr/samples)
		err.append(1-(err_given_snr/samples))
		ber.append((qfunc(mp.sqrt((2*snr)/(f2))))*2)

plt.semilogy(snrdb.T,ber,label='calculated by q-func')
plt.semilogy(snrdb.T,err,'o',label='simulated')
plt.xlabel('signal to noise ratio(in dB)')
plt.ylabel('$P_error/BER$')
plt.legend()
plt.grid()
plt.show()
